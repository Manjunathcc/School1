﻿using MediatR;
using SchoolManagament.API.Commands;
using SchoolManagement.Domain.Interfaces;

namespace SchoolManagament.API.CommandHandlers
{
    public class AddStudentHandler : IRequestHandler<AddStudentCommand, Unit>
    {
        private readonly IStudentRepository studentRepository;
        private readonly ILogger logger;

        public AddStudentHandler(IStudentRepository studentRepository, ILogger logger)
        {
            this.studentRepository = studentRepository;
            this.logger = logger;
        }
        public async Task<Unit> Handle(AddStudentCommand request, CancellationToken cancellationToken)
        {
            try
            {
                this.logger.LogInformation("Addstudent process - started");

                await this.studentRepository.Add(request.student);

                this.logger.LogInformation("Addstudent process - completed");

                return Unit.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
