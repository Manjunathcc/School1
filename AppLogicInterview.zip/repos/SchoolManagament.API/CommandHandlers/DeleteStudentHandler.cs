﻿using MediatR;
using SchoolManagament.API.Commands;
using SchoolManagement.Domain.Interfaces;

namespace SchoolManagament.API.CommandHandlers
{
    public class DeleteStudentHandler : IRequestHandler<DeleteStudentCommand, Unit>
    {
        private readonly IStudentRepository studentRepository;
        private readonly ILogger logger;

        public DeleteStudentHandler(IStudentRepository studentRepository, ILogger logger)
        {
            this.studentRepository = studentRepository;
            this.logger = logger;
        }
        public async Task<Unit> Handle(DeleteStudentCommand request, CancellationToken cancellationToken)
        {
            try
            {
                this.logger.LogInformation($"Id:{request.Id} DeleteStudentHandler - started");

                await this.studentRepository.Delete(request.Id);

                this.logger.LogInformation($"Id:{request.Id} DeleteStudentHandler - completed");

                return Unit.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
