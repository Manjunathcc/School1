﻿using MediatR;
using SchoolManagament.API.Commands;
using SchoolManagement.Domain.Interfaces;

namespace SchoolManagament.API.CommandHandlers
{
    public class UpdateStudentHandler : IRequestHandler<UpdateStudentCommand, Unit>
    {
        private readonly IStudentRepository studentRepository;
        private readonly ILogger logger;

        public UpdateStudentHandler(IStudentRepository studentRepository, ILogger logger)
        {
            this.studentRepository = studentRepository;
            this.logger = logger;
        }
        public async Task<Unit> Handle(UpdateStudentCommand request, CancellationToken cancellationToken)
        {
            try
            {
                this.logger.LogInformation($"Id:{request.Id} UpdateStudentHandler - started");

                await this.studentRepository.Update(request.Id, request.student);

                this.logger.LogInformation($"Id:{request.Id} UpdateStudentHandler - completed");

                return Unit.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
