﻿using MediatR;
using SchoolManagement.Domain.Models;

namespace SchoolManagament.API.Commands
{
    public record AddStudentCommand(Student student) : IRequest<Unit>;
}
