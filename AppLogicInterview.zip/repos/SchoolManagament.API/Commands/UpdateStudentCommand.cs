﻿using MediatR;
using SchoolManagement.Domain.Models;

namespace SchoolManagament.API.Commands
{
    public record UpdateStudentCommand(int Id, Student student) : IRequest<Unit>;
}
