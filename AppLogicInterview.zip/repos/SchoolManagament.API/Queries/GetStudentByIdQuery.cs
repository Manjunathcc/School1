﻿using MediatR;
using SchoolManagement.Domain.Models;

namespace SchoolManagament.API.Queries
{
    public record GetStudentByIdQuery(int id) : IRequest<Student>;
}
