﻿using MediatR;
using SchoolManagement.Domain.Models;

namespace SchoolManagament.API.Queries
{
    public class GetStudentsQuery : IRequest<List<Student>>
    {
    }
}
