﻿using MediatR;
using SchoolManagament.API.Queries;
using SchoolManagement.Domain.Interfaces;
using SchoolManagement.Domain.Models;

namespace SchoolManagament.API.QueryHandlers
{
    public class GetStudentByIdQueryHandler : IRequestHandler<GetStudentByIdQuery, Student>
    {
        private readonly IStudentRepository studentRepository;
        private readonly ILogger logger;

        public GetStudentByIdQueryHandler(IStudentRepository studentRepository, ILogger logger)
        {
            this.studentRepository = studentRepository;
            this.logger = logger;
        }
        public Task<Student> Handle(GetStudentByIdQuery request, CancellationToken cancellationToken)
        {
            try
            {
                this.logger.LogInformation($"Id:{request.id} GetStudentByIdQueryHandler - started");

                var result = this.studentRepository.GetById(request.id);

                this.logger.LogInformation($"Id:{request.id} GetStudentByIdQueryHandler - completed");

                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
