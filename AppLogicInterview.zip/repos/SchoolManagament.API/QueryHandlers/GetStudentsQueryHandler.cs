﻿using MediatR;
using SchoolManagament.API.Queries;
using SchoolManagement.Domain.Interfaces;
using SchoolManagement.Domain.Models;

namespace SchoolManagament.API.QueryHandlers
{
    public class GetStudentsQueryHandler : IRequestHandler<GetStudentsQuery, List<Student>>
    {
        private readonly IStudentRepository studentRepository;
        private readonly ILogger logger;

        public GetStudentsQueryHandler(IStudentRepository studentRepository, ILogger logger)
        {
            this.studentRepository = studentRepository;
            this.logger = logger;
        }
        public Task<List<Student>> Handle(GetStudentsQuery request, CancellationToken cancellationToken)
        {
            try
            {
                this.logger.LogInformation("GetStudentsQueryHandler - started");

                var data = this.studentRepository.Get();

                this.logger.LogInformation("GetStudentsQueryHandler - completed");

                return data;

            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
